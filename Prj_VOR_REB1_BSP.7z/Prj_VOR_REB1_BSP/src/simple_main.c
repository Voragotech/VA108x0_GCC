/**
  ******************************************************************************
  * @file    try1/main.c 
  * @author  CEM
  * @version V1.0.0
  * @date    23-March-2012
  * @brief   Main program body
  ******************************************************************************

  *
  ******************************************************************************
  */

/* Local Includes ------------------------------------------------------------------*/

#include "va108xx.h"




/* Local defines ------------------------------------------------------------*/
#define PORTA_10_D2 			10
#define PORTA_7_D3 				7
#define PORTA_6_D4	 			6
#define PORTA_11_SW_USER 		11


/* Private variables ---------------------------------------------------------*/


/*  function prototypes ------------*/
/* Private functions ---------------------*/
void delay (int a);
/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{


/* Enable clock for all peripherals */
		VOR_SYSCONFIG->PERIPHERAL_CLK_ENABLE = ( CLK_ENABLE_PORTA | CLK_ENABLE_PORTB | CLK_ENABLE_SPIA | CLK_ENABLE_SPIB | CLK_ENABLE_SPIC |
				 CLK_ENABLE_UARTA | CLK_ENABLE_UARTB | CLK_ENABLE_I2CA | CLK_ENABLE_I2CB | CLK_ENABLE_IRQSEL |
				 CLK_ENABLE_IOMGR | CLK_ENABLE_UTILITY | CLK_ENABLE_PORTIO | CLK_ENABLE_SYSTEM );

/* Configure PA[11] as Input .  This is "SW_USER" switch on REB1 board. */
      VOR_GPIO->BANK[0].DIR &= ~(1 << PORTA_11_SW_USER);
      VOR_GPIO->BANK[0].DATAMASK |= (1 << PORTA_11_SW_USER);

/* Configure PA[7]. This GPIO will turn ON LED D3. */
      VOR_GPIO->BANK[0].DIR |= (1 << PORTA_7_D3);
	  VOR_GPIO->BANK[0].DATAMASK |= (1 << PORTA_7_D3);
      VOR_GPIO->BANK[0].DATAOUT |= (1 << PORTA_7_D3);

 int count = 10  ;  


  while (1)
  {
     count ++ ;  
	 delay(500000)  ;  /*  delay 500k counts  */
	 VOR_GPIO->BANK[0].TOGOUT |= (1 << PORTA_7_D3);
    
  }
}
/* **************  foot of main loop  ****************   */
void delay (int a)
{
	volatile int i,j;
	
	for (i=0 ; i < a ; i++)
	{ 
		j++;
	}
	
	return;
}


/********** *****END OF FILE****/
